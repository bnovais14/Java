import java.util.Scanner;
public class Ex5_5 {
    public static void entrada(int [] id){
         Scanner input = new Scanner(System.in);
         System.out.println("Digite os valores");
        for (int i=0; i<id.length;i++)  
            id[i] = input.nextInt();
    }
    public static int contaMenor16(int [] id){
        int ct16=0;
        for (int valor:id)
            if (valor<=16)
                ct16++;
        return ct16;        
    }
    public static int contaMaior16(int [] id){
        int ct16=0;
        for (int valor:id)
            if (valor>16)
                ct16++;
        return ct16;        
    }
    
    public static double idadeMedia(int [] id){
        int soma=0;
        for (int valor:id)
            soma+=valor;
        return((double)soma/id.length);
    }
    
    public static int idadeMaior(int [] id){
        int maior = id[0];
        for (int i=1; i<id.length; i++){
            if (id[i]>maior)
                maior=id[i];
        }
        return maior;
    }
    public static int idadeMenor(int [] id){
        int menor = id[0];
        for (int i=1; i<id.length; i++){
            if (id[i]<menor)
                menor=id[i];
        }
        return menor;
    }
    public static void main(String[] args) {
        int [] idade = new int[4];
        entrada(idade);
        System.out.println("Quantidade de alunos com idade >=16: "+ contaMaior16(idade));
        System.out.println("Quantidade de alunos com idade <16: "+ contaMenor16(idade));
        System.out.println("Média de idade da turma: "+ idadeMedia(idade));
        System.out.println("Idade do mais novo: "+ idadeMenor(idade));
        System.out.println("Idade do mais velho: "+ idadeMaior(idade));         
    }
}
