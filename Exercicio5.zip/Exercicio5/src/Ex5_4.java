import java.util.Scanner;
public class Ex5_4 {
    public static void entrada(int [] v){
         Scanner input = new Scanner(System.in);
         System.out.println("Digite os valores");
        for (int i=0; i<v.length;i++)  
            v[i] = input.nextInt();
    }

    public static void gerarV3(int[]v1, int[]v2, int[]v3){
        for (int i=0; i<v3.length;i++){
            if(v1[i] == v2[i])
                v3[i]=1;
            else
                v3[i]=0;
         }
     }
    public static void mostra(int [] num){
        System.out.println("Número armazenados no vetor");
        for (int v:num)
            System.out.print(v + "  ");
        System.out.println("\n");
    }
    public static void main(String[] args) {
   int[] v1 = new int[15];
   int[] v2 = new int[15];
   int[] v3 = new int[15];
   entrada(v1);
   entrada(v2);
   gerarV3(v1,v2,v3);
   mostra(v1);
   mostra(v2);
   mostra(v3);
}
    
}
