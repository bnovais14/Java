import java.util.Scanner;
public class Ex5_3 {
     public static void entrada(int [] v){
         Scanner input = new Scanner(System.in);
         System.out.println("Digite os valores");
        for (int i=0; i<v.length;i++)  
            v[i] = input.nextInt();
    }
    public static void mostraValores(int [] v){
        System.out.println("Valores que estão nas posições impares");
        for(int i=0; i<v.length; i++)
            if(i%2!=0)
                System.out.println(v[i]+ " ");
      }
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Digite a quantidade de elementos: ");
        int qt = input.nextInt();
        int [] vetor = new int[qt];
        entrada(vetor);
        mostraValores(vetor);
        
    }
    
}
