
public class Ex5_1 {
    public static void entrada(int [] num){
        for (int i=0; i<30;i++)  
            num[i] = i*i;
    }
    
    public static void saida(int [] num){
        System.out.println("Número armazenados no vetor");
        for (int v:num)
            System.out.print(v + "  ");
        System.out.println("\n");
    }
    
    public static void main(String[] args) { 
        int [] num = new int[30];
        entrada(num);
        saida(num);
              
    }
    
}
