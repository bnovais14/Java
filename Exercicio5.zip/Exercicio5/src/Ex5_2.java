
public class Ex5_2 {
    public static int contaNegativos(double [] vetor){
        int ct=0;
        for(double v:vetor)
            if (v<0)
                ct++;
        return ct;
    }
    public static double somaPositivos(double [] vetor){
        double soma=0;
        for(double v:vetor)
            if (v>0)
                soma+=v;
        return soma;
    } 
    public static void main(String[] args) {
        double [] vetor = {1,2,3,4,-5,6,7,8,-9,10};
        System.out.println("Quantidade de negativos:"+ contaNegativos(vetor));
        System.out.println("Soma dos positivos: "+ somaPositivos(vetor));
    }
}
