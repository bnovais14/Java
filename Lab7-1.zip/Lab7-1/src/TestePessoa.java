/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 31951155
 */
public class TestePessoa {
    
    public static void main(String[] args) {
        Pessoa p1 = new Pessoa("Beatriz", 18, (float)1.68);
        
        System.out.println("O  nome: " + p1.getNome());
        System.out.println("A idade: " + p1.getIdade());
        System.out.println("A altura " + p1.getAltura());
    }
}
