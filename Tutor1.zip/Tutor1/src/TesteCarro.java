// Beatriz Novais Barreto 2F
import java.util.Scanner;


public class TesteCarro {
    public static void main(String[] args) {
        Carro fusca;
        fusca = new Carro();
        fusca.ligar();
        fusca.buzinar();
        
        
        fusca.velocidadeMaxima = 100;
        
        Scanner ent = new Scanner (System.in);
        System.out.println("Quanto você quer acelerar?");
        double valor = ent.nextDouble();
        int teste = fusca.acelerar(valor);
        System.out.println("A velocidade atual é "+ fusca.velocidadeAtual + "km/h");
        
        if (teste== -1)
            System.out.println("A velocidade é igual ou superior á velocidade máxima");
        
        int teste2 = fusca.pegarMarcha ();
        if (teste2 == -1)
        {
            System.out.println("Carro parado");
            fusca.desligar();
        }
        else if (teste2==1)
            System.out.println("1ª marcha");
         else if (teste2==2)
            System.out.println("2ª marcha");
         else if (teste2==3)
            System.out.println("3ª marcha");
         else if (teste2==4)
            System.out.println("4ª marcha");
         else 
             System.out.println("5ª marcha"); 
        
        //Exercicio finalizado
      
        
        
    }
}
