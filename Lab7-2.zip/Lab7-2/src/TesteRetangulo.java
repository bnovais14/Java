
import java.util.Scanner;


public class TesteRetangulo {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        Retangulo ret = new Retangulo();
        
        System.out.println("Digite a largura: ");
        double largura = input.nextDouble();
        ret.setLargura(largura);
        
        System.out.println("Digite a altura: ");
        double alt = input.nextDouble();
        ret.setAltura(alt);
        
        System.out.println("Perimetro: " + ret.calculaPerimetro());
        System.out.println("Area: " + ret.calculaArea());
        
        
        
        
    }
}
