/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 31951155
 */
public class Retangulo {
    private double largura;
    private double altura;
    
    
     
        
      double calculaPerimetro(){
        
      
       
        
        return (2*(largura+altura));
         }
      
     double calculaArea(){
       
       
        
        return (largura*altura);
         }
     
      public void setLargura(double largura){
          this.largura = largura;
      }
     public void setAltura(double altura){
          this.altura = altura;
      }
}
