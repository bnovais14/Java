
import java.util.Scanner;


public class ex1 {
    public static void entrada(int [] vet1){
          Scanner input = new Scanner(System.in);
        System.out.println("Digite o saldo da sua conta:");
        for (int i=0; i<vet1.length; i++){
            vet1[i]= input.nextInt();
        }
    }
    public static void menu(){
       System.out.println("----------------------------------");
        System.out.println("----------------------------------");
        System.out.println("1- Consultar saldo da conta 1");
        System.out.println("2- Consultar saldo da conta 2");
        System.out.println("3- Consultar saldo da conta 3");
        System.out.println("4- Depositar R$ 10 na conta 1");
        System.out.println("5- Depositar R$ 10 na conta 2");
        System.out.println("6- Depositar R$ 10 na conta 3");
        System.out.println("7- Sacar R$ 3 da conta 1");
        System.out.println("8- Sacar R$ 3 da conta 2");
        System.out.println("9- Sacar R$ 3 da conta 3");
        System.out.println("10- sair");
        System.out.println("----------------------------------");
        System.out.println("----------------------------------");
    }
    
    public static void main(String[] args) {
        int [] vet1 = new int[3];
        int op;
        entrada(vet1);
        menu();
        Scanner input = new Scanner(System.in);
        op = input.nextInt();
        switch(op){
            case 1:
                if (op == 1){
                    System.out.println("O saldo da conta 1 é de :  R$" + vet1[0]);
                    System.out.println("Digite um número do menu:");
                    op = input.nextInt();
                }
            case 2:
                if (op == 2){
                    System.out.println("O saldo da conta 2 é de :  R$" + vet1[1]);
                    System.out.println("Digite um número do menu:");
                    op = input.nextInt();
                                    }
            case 3:
                if (op == 3){
                    System.out.println("O saldo da conta 3 é de :  R$" + vet1[2]);
                    System.out.println("Digite um número do menu:");
                    op = input.nextInt();
                                    }
            case 4:
                if (op == 4){
                    System.out.println("O valor atual da conta 1 é de :  R$" + (vet1[0]+10));
                    System.out.println("Digite um número do menu:");
                    op = input.nextInt();
                                    }
            case 5:
                if (op == 5){
                    System.out.println("O valor atual da conta 2 é de :  R$" + (vet1[1]+10));
                    System.out.println("Digite um número do menu:");
                    op = input.nextInt();
                                    }
            case 6:
                if (op == 6){
                    System.out.println("O valor atual da conta 3 é de :  R$" + (vet1[2]+10));
                    System.out.println("Digite um número do menu:");
                    op = input.nextInt();
                                    }
            case 7:
                if (op == 7){
                    System.out.println("O valor atual da conta 1 é de :  R$" + (vet1[0]-3));
                    System.out.println("Digite um número do menu:");
                    op = input.nextInt();
                                    }
            case 8:
                if (op == 8){
                    System.out.println("O valor atual da conta 2 é de :  R$" + (vet1[1]-3));
                    System.out.println("Digite um número do menu:");
                    op = input.nextInt();
                                    }
            case 9:
                if (op == 9){
                    System.out.println("O valor atual da conta 3 é de :  R$" + (vet1[2]-3));
                    System.out.println("Digite um número do menu:");
                    op = input.nextInt();
                                    }
            case 10:
                if (op == 10){
                    System.out.println("Saindo..." );
                     System.out.println(".........." );
                    
                                    }
        }
      
         
        
    }
}
